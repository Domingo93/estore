package www.domingo.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import java.sql.SQLException;
import java.sql.Statement;
import javax.sql.DataSource;

public class MyJdbcUtil {
	public static final String url = "jdbc:mysql://localhost:3306/estore";
	public static final String driver = "com.mysql.jdbc.Driver";
	public static final String user = "root";
	public static final String password = "123456";

	public Connection conn = null;
	public PreparedStatement pst = null;
	public Statement stat = null;
	private Statement statement;

	public PreparedStatement createPst(String sql) {
		try {
			Class.forName(driver);// ָ����������
			conn = DriverManager.getConnection(url, user, password);// ��ȡ����
			pst = conn.prepareStatement(sql);// ׼��ִ�����
			return pst;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Statement createStatement() throws SQLException, ClassNotFoundException {
		Class.forName(driver);// ָ����������
		conn = DriverManager.getConnection(url, user, password);// ��ȡ����
		statement = conn.createStatement();
		return statement;
	}

	public void close(int i) {
		try {
			this.conn.close();
			if (i == 1) {
				this.pst.close();
			} else {
				this.statement.close();
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

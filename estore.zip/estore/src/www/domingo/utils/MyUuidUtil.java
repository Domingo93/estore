package www.domingo.utils;

import java.util.UUID;

public class MyUuidUtil {
	public static String getUUID(){
		return UUID.randomUUID().toString().replace("-", "");
	}
}

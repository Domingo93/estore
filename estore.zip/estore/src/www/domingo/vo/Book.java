package www.domingo.vo;

public class Book {
	private String bid;
	private String bname;
	private double price;
	private int numincart;
	private int numinorder;

	public int getNumincart() {
		return numincart;
	}
	public void setNumincart(int numincart) {
		this.numincart = numincart;
	}
	public int getNuminorder() {
		return numinorder;
	}
	public void setNuminorder(int numinorder) {
		this.numinorder = numinorder;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	private String author;
	private String image;
	private int isdel;
	public String getBid() {
		return bid;
	}
	public void setBid(String bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getIsdel() {
		return isdel;
	}
	public void setIsdel(int isdel) {
		this.isdel = isdel;
	}
	public Book() {
		super();
	}
	
	
	
}

package www.domingo.service;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import www.domingo.dao.UserDao;
import www.domingo.dao.UserDaoImpl;
import www.domingo.utils.MyUuidUtil;
import www.domingo.vo.User;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.MimeMessage.RecipientType;

import com.sun.mail.smtp.SMTPTransport;

public class UserService {

	public int registUser(User user)
			throws SQLException, ClassNotFoundException, MessagingException, UnsupportedEncodingException {
		UserDao dao = new UserDaoImpl();
		user.setUid(MyUuidUtil.getUUID());
		user.setState(0);
		String code = MyUuidUtil.getUUID() + MyUuidUtil.getUUID();
		user.setCode(code);
		user.setAuthorisation(4);
		int isdone = dao.saveUser(user);
		if (isdone == 1) {
			//sendEmailWithCode(code, user.getEmail());
		}
		return isdone;
	}

	public int active(String code) throws SQLException {
		UserDao dao = new UserDaoImpl();
		int isValidated = dao.active(code);
		return isValidated;
	}

	public void sendEmailWithCode(String code, String email) throws MessagingException, UnsupportedEncodingException {
		// ����javamail
		final String SENDCLOUD_SMTP_HOST = "smtp.sendcloud.net";
		final int SENDCLOUD_SMTP_PORT = 25;
		Properties props = System.getProperties();
		props.setProperty("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", SENDCLOUD_SMTP_HOST);
		props.put("mail.smtp.port", SENDCLOUD_SMTP_PORT);
		props.setProperty("mail.smtp.auth", "true");
		props.put("mail.smtp.connectiontimeout", 180);
		props.put("mail.smtp.timeout", 600);
		props.setProperty("mail.mime.encodefilename", "true");
		// ʹ��api_user��api_key������֤
		final String apiUser = "Domingo_test_IEv48o";
		final String apiKey = "m0VZqBYj3EWo0jVx";
		String to = email;
		Session mailSession = Session.getInstance(props, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(apiUser, apiKey);
			}
		});
		SMTPTransport transport = (SMTPTransport) mailSession.getTransport("smtp");

		MimeMessage message = new MimeMessage(mailSession);
		// ������
		message.setFrom(new InternetAddress("from@domingo.pw", "domindo", "UTF-8"));
		// �ռ��˵�ַ
		message.addRecipient(RecipientType.TO, new InternetAddress(to));
		// �ʼ�����
		message.setSubject("your active code", "UTF-8");

		Multipart multipart = new MimeMultipart("alternative");
		// ����html��ʽ���ʼ�����
		String html = "<html><head></head><body>" + "<p>��ӭʹ�ñ���Ʒ��������Ӽ��������˻�: "
				+ "<a href="+ "http://domingo.ecs04.tomcats.pw/estore/user?method=validate&code="+code+">����˴����ע��</a> "+ " </p>" + "</body></html> ";
		BodyPart contentPart = new MimeBodyPart();
		contentPart.setHeader("Content-Type", "text/html;charset=UTF-8");
		contentPart.setContent(html, "text/html;charset=UTF-8");
		multipart.addBodyPart(contentPart);
		message.setContent(multipart);
		// ����sendcloud�������������ʼ�
		transport.connect();
		transport.sendMessage(message, message.getRecipients(RecipientType.TO));
		transport.close();
	}

	public int login(User user) throws SQLException {
		UserDao dao = new UserDaoImpl();
		User user1 =  dao.login(user);
		if(user1.getPassword()==null){
			return 0;
		}else if(user.getPassword().equals(user1.getPassword())){
			if(checkState(user1)){
				return 1;
			}else{
				return 2;
			}
		}else {
			return 3;
		}
	}

	private boolean checkState(User user1) {
		if(user1.getState() == 1){
			return true;
		}
		return false;
	}

}

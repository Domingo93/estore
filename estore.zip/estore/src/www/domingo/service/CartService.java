package www.domingo.service;

import java.sql.SQLException;
import java.util.List;

import www.domingo.dao.CartDao;
import www.domingo.dao.CartDaoImpl;
import www.domingo.vo.Book;

public class CartService {

	public int addBookToCart(String bid, String num, String username) throws ClassNotFoundException, SQLException {
		CartDao dao = new CartDaoImpl();
		return dao.addBookToCart(bid,num,username);
		
	}

	public List<Book> listAllBooksInCart(String username) throws ClassNotFoundException, SQLException {
		CartDao dao = new CartDaoImpl();
		List<Book> bList = dao.listAllBooksInCart(username);
		List<Book> bList2 = dao.setRestAttribute(bList);
		return bList2;
	}

	public int delBookfromCart(String username, String bid) throws SQLException, ClassNotFoundException {
		CartDao dao = new CartDaoImpl();
		return dao.delBookfromCart(username,bid);
	}

	public int clearAll(String username) throws ClassNotFoundException, SQLException {
		CartDao dao = new CartDaoImpl();
		return dao.clearAll(username);
	}

}

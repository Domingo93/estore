package www.domingo.service;

import java.sql.SQLException;
import java.util.List;

import www.domingo.dao.CategoryDao;
import www.domingo.dao.CategoryDaoImpl;
import www.domingo.vo.Category;

public class CategoryService {

	public List<Category> findAll() throws SQLException {
		CategoryDao dao = new CategoryDaoImpl();
		return dao.findAll();
	}
	
}

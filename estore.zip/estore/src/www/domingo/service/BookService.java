package www.domingo.service;


import java.sql.SQLException;
import java.util.List;

import www.domingo.dao.BookDao;
import www.domingo.dao.BookDaoImpl;
import www.domingo.vo.Book;

public class BookService {

	public List<Book> findAll() throws SQLException {
		BookDao dao = new BookDaoImpl();
		return dao.findAll();
		
	}

	public List<Book> findByCid(String cid) throws SQLException {
		BookDao dao = new BookDaoImpl();
		return dao.findByCid(cid);

	}

	public Book findDescByBid(String bid) throws SQLException {
		BookDao dao = new BookDaoImpl();
		return dao.findDescByBid(bid);
	}

}

package www.domingo.servlet;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import www.domingo.service.CategoryService;
import www.domingo.vo.Category;

/**
 * Servlet implementation class Category
 */
@WebServlet("/category")
public class CategoryServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	
	public String findAll(HttpServletRequest request,HttpServletResponse response) throws SQLException{
		CategoryService categoryService = new CategoryService();
		List<Category> clist = categoryService.findAll();
		request.setAttribute("clist", clist);
		return "/jsps/left.jsp";
	}
	
	
	
}

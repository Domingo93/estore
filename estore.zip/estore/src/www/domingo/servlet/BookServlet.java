package www.domingo.servlet;


import java.sql.SQLException;
import java.text.Bidi;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import www.domingo.service.BookService;
import www.domingo.vo.Book;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/book")
public class BookServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	
	public String findAll(HttpServletRequest request,HttpServletResponse response) throws SQLException {
		BookService bService = new BookService();
		List<Book> blist = bService.findAll();
		request.setAttribute("blist", blist);
		return "/jsps/book/list.jsp";
		
	}
	
	public String findByCid(HttpServletRequest request,HttpServletResponse response) throws SQLException{
		String cid = (String) request.getParameter("cid");
		BookService bService = new BookService();
		List<Book> blist = bService.findByCid(cid);
		request.setAttribute("blist", blist);
		return "/jsps/book/list.jsp";
		
	}
	
	public String findDescByBid(HttpServletRequest request,HttpServletResponse response) throws SQLException{
		String bid = request.getParameter("bid");
		BookService bService = new BookService();
		Book book = bService.findDescByBid(bid);
		request.setAttribute("book", book);
		return "/jsps/book/desc.jsp";
		
	}
	
}

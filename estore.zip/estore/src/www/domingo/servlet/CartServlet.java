package www.domingo.servlet;


import java.sql.SQLException;
import java.util.List;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import www.domingo.service.CartService;
import www.domingo.vo.Book;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/cart")
public class CartServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;

	public String addBookToCart(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException{
		String bid;
		String num;
		CartService cartService;
		int flag;
		String username;
		if(request.getSession().getAttribute("username") != null){
			username = (String) request.getSession().getAttribute("username");
			bid =  request.getParameter("bid");
			num = request.getParameter("count");
			cartService = new CartService();
			flag = cartService.addBookToCart(bid,num,username);
		}else{
			request.setAttribute("msg", "�����ȵ�¼");
			return "/jsps/msg1.jsp";
		}
		if(flag==1){
			request.setAttribute("msg", "���ӳɹ�");
			return "/jsps/msg1.jsp";
		}else if(flag==0){
			request.setAttribute("msg", "�ƺ�����ʧ������");
			return "/jsps/msg1.jsp";
		}
		return null;
	}
	
	public String listAllBooksInCart(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException{
		String username = (String) request.getSession().getAttribute("username");
		CartService cartService = new CartService();
		List<Book> bList = cartService.listAllBooksInCart(username);
		request.setAttribute("bList", bList);
		return "/jsps/cart/list.jsp";
	}
	
	public String delBookfromCart(HttpServletRequest request,HttpServletResponse response) throws SQLException, ClassNotFoundException{
		String bid = request.getParameter("bid");
		String username = (String) request.getSession().getAttribute("username");
		CartService cartService = new CartService();
		int flag = cartService.delBookfromCart(username,bid);
		if(flag==1){
			request.setAttribute("msg", "ɾ���ɹ�");
			return "/jsps/msg1.jsp";
		}else {
			request.setAttribute("msg", "ɾ��ʧ��");
			return "/jsps/msg1.jsp";
		}
	}
	
	public String clearAll(HttpServletRequest request,HttpServletResponse response) throws ClassNotFoundException, SQLException{
		String username = (String) request.getSession().getAttribute("username");
		CartService cartService = new CartService();
		int flag = cartService.clearAll(username);
		if(flag>=1){
			request.setAttribute("msg", "ɾ���ɹ�");
			return "/jsps/msg1.jsp";
		}else {
			request.setAttribute("msg", "ɾ��ʧ��");
			return "/jsps/msg1.jsp";
		}
	}
	
	
	
	
}

package www.domingo.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sun.xml.internal.ws.developer.StreamingAttachment;

import www.domingo.utils.MyJdbcUtil;
import www.domingo.vo.Book;

public class CartDaoImpl implements CartDao {

	@Override
	public int addBookToCart(String bid, String num,String username) throws ClassNotFoundException, SQLException {
		int num1 = Integer.parseInt(num);
		int flag = ifItemExistInCart(bid,username);
		if(flag != 0){
			num1 = addNumInCart(bid,num1,username);
			MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
			String sqlForUpdate = "update " + username + "_items " + "set numincart=" + num1 + " where bid=" + bid;
			Statement statement = myJdbcUtil.createStatement();
			statement.executeUpdate(sqlForUpdate);
			myJdbcUtil.close(2);
			return 1;
		}else{
			String sql = "insert into " + username + "_items (bid,numincart)" + " values(" + bid + ","+num1+")";
			MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
			Statement statement = myJdbcUtil.createStatement();
			statement.execute(sql);
			myJdbcUtil.close(2);
			return 1;
		}
		
	}

	private int ifItemExistInCart(String bid, String username) throws ClassNotFoundException, SQLException {
		String sql = "select * from " + username + "_items" + " where bid=" + bid;
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		Statement statement = myJdbcUtil.createStatement();
		ResultSet rSet = statement.executeQuery(sql);
		while(rSet.next()){
			return 1;
		}
		return 0;
	}

	private int addNumInCart(String bid,int num,String username) throws ClassNotFoundException, SQLException {
		String sql = "select * from " + username + "_items" + " where bid=" + bid;
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		Statement statement = myJdbcUtil.createStatement();
		ResultSet rSet = statement.executeQuery(sql);
		while(rSet.next()){
				num = rSet.getInt("numincart") + num;
		}
		myJdbcUtil.close(2);
		return num;
	}

	@Override
	public List<Book> listAllBooksInCart(String username) throws ClassNotFoundException, SQLException {
		String sql = "select bid,numincart from " + username + "_items";
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		Statement statement = myJdbcUtil.createStatement();
		ResultSet rSet = statement.executeQuery(sql);
		List<Book> bList = new ArrayList<Book>();
		while(rSet.next()){
			if (rSet.getInt("numincart")!=0) {
				Book book = new Book();
				book.setBid(rSet.getString("bid"));
				book.setNumincart(rSet.getInt("numincart"));
				bList.add(book);
			}
		}
		myJdbcUtil.close(2);
		return bList;
	}

	@Override
	public List<Book> setRestAttribute(List<Book> bList) throws ClassNotFoundException, SQLException {
		String sql = "select * from book where bid=";
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		Statement statement = myJdbcUtil.createStatement();
		for(int i=0;i<bList.size();i++){
			ResultSet rSet = statement.executeQuery(sql + bList.get(i).getBid());
			while(rSet.next()){
				if(rSet.getInt("isdel") == 1){
					bList.get(i).setAuthor(rSet.getString("author"));
					bList.get(i).setBname(rSet.getString("bname"));
					bList.get(i).setImage(rSet.getString("image"));
					bList.get(i).setPrice(rSet.getDouble("price"));
				}
			}
		}
		myJdbcUtil.close(2);
		return bList;
	}

	@Override
	public int delBookfromCart(String username, String bid) throws SQLException, ClassNotFoundException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "UPDATE " + username + "_items" + " SET numincart=0 WHERE bid=" + bid;
		Statement statement = myJdbcUtil.createStatement();
		int flag = statement.executeUpdate(sql);
		myJdbcUtil.close(2);
		return flag;
	}

	@Override
	public int clearAll(String username) throws ClassNotFoundException, SQLException {
		String sql = "UPDATE " + username + "_items" + " SET numincart=0";
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		Statement statement = myJdbcUtil.createStatement();
		int flag = statement.executeUpdate(sql);
		myJdbcUtil.close(2);
		return flag;
	}


}

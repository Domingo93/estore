package www.domingo.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import www.domingo.utils.MyJdbcUtil;
import www.domingo.vo.Category;

public class CategoryDaoImpl implements CategoryDao {

	@Override
	public List<Category> findAll() throws SQLException {
		MyJdbcUtil util = new MyJdbcUtil();
		String sql = "select * from category";
		PreparedStatement pStatement = util.createPst(sql);
		ResultSet resultSet = pStatement.executeQuery();
		List<Category> clist = new ArrayList<>();
		while(resultSet.next()){
			Category category = new Category();
			category.setCid(resultSet.getString("cid"));
			category.setCname(resultSet.getString("cname"));
			clist.add(category);
		}
		return clist;
	}
	
}

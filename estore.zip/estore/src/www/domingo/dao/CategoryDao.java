package www.domingo.dao;

import java.sql.SQLException;
import java.util.List;

import www.domingo.vo.Category;

public interface CategoryDao {

	List<Category> findAll() throws SQLException;

}

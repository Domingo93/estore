package www.domingo.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.sun.mail.imap.protocol.UID;

import www.domingo.utils.MyJdbcUtil;
import www.domingo.utils.MyUuidUtil;
import www.domingo.vo.User;

public class UserDaoImpl implements UserDao {

	public int saveUser(User user) throws SQLException, ClassNotFoundException {
		int isExist = isExist(user);// �û����ڷ���2,�����ڷ���1
		if (isExist == 2) {
			return 2;
		}
		String sql = "insert into user values(?,?,?,?,?,?,?)";
		String sql1 = "CREATE TABLE " + user.getUsername()+ "_items" + " (id bigint(255) NOT NULL AUTO_INCREMENT,bid varchar(32) NULL ,numincart int NOT NULL DEFAULT 0,numinorder int NOT NULL DEFAULT 0,delinorder tinyint NOT NULL DEFAULT 1, PRIMARY KEY (id))";
		MyJdbcUtil util = new MyJdbcUtil();
		PreparedStatement pst = util.createPst(sql);
		pst.setString(1, MyUuidUtil.getUUID());
		pst.setString(2, user.getUsername());
		pst.setString(3, user.getPassword());
		pst.setString(4, user.getEmail());
		pst.setInt(5, 0);
		pst.setString(6, user.getCode());
		pst.setInt(7, 4);
		int rs = pst.executeUpdate();
		util.close(1);//1��ps,2��stat
		if (rs > 0) {
			Statement statement = util.createStatement();
			statement.execute(sql1);
			return 1;
		}
		return 0;
	}

	private int isExist(User user) throws SQLException, ClassNotFoundException {
		String sql = "select username from user where username=" + "'" + user.getUsername() + "'";
		MyJdbcUtil util = new MyJdbcUtil();
		Statement statement = util.createStatement();
		ResultSet rs = statement.executeQuery(sql);
		while (rs.next()) {
			return 2;
		}
		util.close(2);
		return 1;
	}


	@Override
	public int active(String code) throws SQLException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "update user set state=? where code=?";
		PreparedStatement pStatement = myJdbcUtil.createPst(sql);
		pStatement.setInt(1, 1);
		pStatement.setString(2, code);
		int result = pStatement.executeUpdate();
		myJdbcUtil.close(1);
		return result;
	}

	@Override
	public User login(User user) throws SQLException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "select * from user where username=?";
		PreparedStatement pStatement = myJdbcUtil.createPst(sql);
		pStatement.setString(1, user.getUsername());
		ResultSet rSet = pStatement.executeQuery();
		User user1 = new User();
		while(rSet.next()){
			user1.setUid(rSet.getString("uid"));
			user1.setPassword(rSet.getString("password"));
			user1.setState(rSet.getInt("state"));
		}
		myJdbcUtil.close(1);
		return user1;
	}

}

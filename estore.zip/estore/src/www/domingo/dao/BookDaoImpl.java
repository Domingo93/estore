package www.domingo.dao;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mysql.jdbc.EscapeTokenizer;

import www.domingo.utils.MyJdbcUtil;
import www.domingo.vo.Book;

public class BookDaoImpl implements BookDao {

	@Override
	public List<Book> findAll() throws SQLException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "select * from book where isdel = 1";
		PreparedStatement pStatement = myJdbcUtil.createPst(sql);
		ResultSet rSet = pStatement.executeQuery();
		List<Book> blist = new ArrayList<>();
		while(rSet.next()){
			Book book = new Book();
			book.setAuthor(rSet.getString("author"));
			book.setBid(rSet.getString("bid"));
			book.setBname(rSet.getString("bname"));
			book.setImage(rSet.getString("image"));
			book.setIsdel(rSet.getInt("isdel"));
			book.setPrice(rSet.getDouble("price"));
			blist.add(book);
		}
		return blist;
	}

	@Override
	public List<Book> findByCid(String cid) throws SQLException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "select * from book where cid=? and isdel = 1";
		PreparedStatement pStatement = myJdbcUtil.createPst(sql);
		pStatement.setString(1, cid);
		ResultSet rSet = pStatement.executeQuery();
		List<Book> blist = new ArrayList<>();
		while(rSet.next()){
			Book book = new Book();
			book.setAuthor(rSet.getString("author"));
			book.setBid(rSet.getString("bid"));
			book.setBname(rSet.getString("bname"));
			book.setImage(rSet.getString("image"));
			book.setIsdel(rSet.getInt("isdel"));
			book.setPrice(rSet.getDouble("price"));
			blist.add(book);
		}
		return blist;
	}

	@Override
	public Book findDescByBid(String bid) throws SQLException {
		MyJdbcUtil myJdbcUtil = new MyJdbcUtil();
		String sql = "select * from book where bid=? and isdel = 1";
		PreparedStatement pStatement = myJdbcUtil.createPst(sql);
		pStatement.setString(1, bid);
		ResultSet rSet = pStatement.executeQuery();
		Book book = new Book();
		while(rSet.next()){
			book.setAuthor(rSet.getString("author"));
			book.setBid(rSet.getString("bid"));
			book.setBname(rSet.getString("bname"));
			book.setImage(rSet.getString("image"));
			book.setIsdel(rSet.getInt("isdel"));
			book.setPrice(rSet.getDouble("price"));
		}
		return book;
	}
	
}

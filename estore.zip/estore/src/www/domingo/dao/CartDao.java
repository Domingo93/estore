package www.domingo.dao;

import java.sql.SQLException;
import java.util.List;

import www.domingo.vo.Book;

public interface CartDao {

	int addBookToCart(String bid, String num, String username) throws ClassNotFoundException, SQLException;

	List<Book> listAllBooksInCart(String username) throws ClassNotFoundException, SQLException;

	List<Book> setRestAttribute(List<Book> bList) throws ClassNotFoundException, SQLException;

	int delBookfromCart(String username, String bid) throws SQLException, ClassNotFoundException;

	int clearAll(String username) throws ClassNotFoundException, SQLException;


}

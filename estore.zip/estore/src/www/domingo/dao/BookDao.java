package www.domingo.dao;


import java.sql.SQLException;
import java.util.List;

import www.domingo.vo.Book;

public interface BookDao {

	List<Book> findAll() throws SQLException;

	List<Book> findByCid(String cid) throws SQLException;

	Book findDescByBid(String bid) throws SQLException;

}

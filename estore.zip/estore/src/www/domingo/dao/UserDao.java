package www.domingo.dao;

import java.sql.SQLException;

import www.domingo.vo.User;



public interface UserDao {

	int saveUser(User user) throws SQLException, ClassNotFoundException;

	int active(String code) throws SQLException;

	User login(User user) throws SQLException;

}

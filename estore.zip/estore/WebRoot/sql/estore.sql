/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50719
Source Host           : localhost:3306
Source Database       : estore

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2017-10-21 02:50:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `bid` varchar(32) NOT NULL,
  `bname` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `cid` varchar(32) DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`bid`),
  KEY `cid` (`cid`),
  CONSTRAINT `cid` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('1', '封神榜', '50.00', '姜子牙', 'book_img/xh1.jpg', '1', '1');
INSERT INTO `book` VALUES ('10', '精通Hibernate', '67.00', '孙鑫', 'book_img/kj2.jpg', '6', '1');
INSERT INTO `book` VALUES ('11', 'Java编程思想', '108.00', 'James', 'book_img/kj4.jpg', '6', '1');
INSERT INTO `book` VALUES ('12', 'Struts2详解', '42.00', '涛哥', 'book_img/kj8.jpg', '6', '1');
INSERT INTO `book` VALUES ('13', 'JavaWeb开发详解', '32.00', '涛哥', 'book_img/kj5.jpg', '6', '1');
INSERT INTO `book` VALUES ('2', '剑逆苍穹', '40.00', '大法官', 'book_img/xh2.jpg', '1', '1');
INSERT INTO `book` VALUES ('3', '薄环凉色', '28.00', '甄嬛', 'book_img/yq1.jpg', '2', '1');
INSERT INTO `book` VALUES ('4', '旋风侠盗', '61.00', '阿园', 'book_img/wx1.jpg', '5', '1');
INSERT INTO `book` VALUES ('5', '你懂我的爱', '73.00', '莫言', 'book_img/yq2.jpg', '2', '1');
INSERT INTO `book` VALUES ('6', '东归喋血', '48.00', '张瑞峰', 'book_img/wx2.jpg', '5', '1');
INSERT INTO `book` VALUES ('7', '守夜', '62.00', '斯蒂芬金', 'book_img/kb1.jpg', '4', '1');
INSERT INTO `book` VALUES ('8', '日本恐怖小说选', '39.00', '村山魁多', 'book_img/kb2.jpg', '3', '1');
INSERT INTO `book` VALUES ('9', 'Java培训就业教程', '58.00', '张孝祥', 'book_img/kj1.jpg', '6', '1');

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cid` varchar(32) NOT NULL,
  `cname` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', '玄幻');
INSERT INTO `category` VALUES ('2', '言情');
INSERT INTO `category` VALUES ('3', '恐怖');
INSERT INTO `category` VALUES ('4', '武侠');
INSERT INTO `category` VALUES ('5', '科技');
INSERT INTO `category` VALUES ('6', 'JavaEE');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` varchar(32) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `state` tinyint(1) DEFAULT '0',
  `code` varchar(64) DEFAULT NULL,
  `authorisation` tinyint(1) DEFAULT '4',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
